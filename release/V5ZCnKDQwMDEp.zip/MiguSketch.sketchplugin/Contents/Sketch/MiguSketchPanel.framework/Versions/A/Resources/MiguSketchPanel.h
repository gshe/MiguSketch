//
//  .h
//  MiguSketchPanel
//
//  Created by George She on 2018/11/8.
//  Copyright © 2018 CMRead. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for .
FOUNDATION_EXPORT double MiguSketchPanelVersionNumber;

//! Project version string for .
FOUNDATION_EXPORT const unsigned char MiguSketchPanelVersionString[];


