var onStartup = function(context) {
  var MiguSketchPanel_FrameworkPath = MiguSketchPanel_FrameworkPath || COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
  var MiguSketchPanel_Log = MiguSketchPanel_Log || log;
  (function() {
    var mocha = Mocha.sharedRuntime();
    var frameworkName = "MiguSketchPanel";
    var directory = MiguSketchPanel_FrameworkPath;
    if (mocha.valueForKey(frameworkName)) {
      MiguSketchPanel_Log("😎 loadFramework: `" + frameworkName + "` already loaded.");
      return true;
    } else if ([mocha loadFrameworkWithName:frameworkName inDirectory:directory]) {
      MiguSketchPanel_Log("✅ loadFramework: `" + frameworkName + "` success!");
      mocha.setValue_forKey_(true, frameworkName);
      return true;
    } else {
      MiguSketchPanel_Log("❌ loadFramework: `" + frameworkName + "` failed!: " + directory + ". Please define MiguSketchPanel_FrameworkPath if you're trying to @import in a custom plugin");
      return false;
    }
  })();
    var manager = MiguSketchLauncher.sharedLauncher();
    manager.setAppMetadata(MSApplicationMetadata.metadata());
    manager.onStartup(context);
};

var onOpenDocument = function(context){
    var MiguSketchPanel_FrameworkPath = MiguSketchPanel_FrameworkPath || COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
    var MiguSketchPanel_Log = MiguSketchPanel_Log || log;
    (function() {
     var mocha = Mocha.sharedRuntime();
     var frameworkName = "MiguSketchPanel";
     var directory = MiguSketchPanel_FrameworkPath;
     if (mocha.valueForKey(frameworkName)) {
     MiguSketchPanel_Log("😎 loadFramework: `" + frameworkName + "` already loaded.");
     return true;
     } else if ([mocha loadFrameworkWithName:frameworkName inDirectory:directory]) {
     MiguSketchPanel_Log("✅ loadFramework: `" + frameworkName + "` success!");
     mocha.setValue_forKey_(true, frameworkName);
     return true;
     } else {
     MiguSketchPanel_Log("❌ loadFramework: `" + frameworkName + "` failed!: " + directory + ". Please define MiguSketchPanel_FrameworkPath if you're trying to @import in a custom plugin");
     return false;
     }
     })();
    
    var manager = MiguSketchLauncher.sharedLauncher();
   manager.setAppMetadata(MSApplicationMetadata.metadata());
    manager.onOpenDocument(context);
}

var onCloseDocument = function(context){
    var manager = MiguSketchLauncher.sharedLauncher();
    manager.onCloseDocument(context);
}


var onShutdown = function(context){
    var manager = MiguSketchLauncher.sharedLauncher();
    manager.onShutdown(context);
}

var onRun = function(context){
    var manager = MiguSketchLauncher.sharedLauncher();
    manager.openMainPanel(context);
}

var onSelectionChanged = function(context) {
  MiguSketchPanel.onSelectionChanged(context);
};
